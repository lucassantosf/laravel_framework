<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(UsersSeeder::class);
        $this->call(RolesSeeder::class);
        $this->call(InformacoesSeeder::class);
        $this->call(EspecialidadesSeeder::class);
        $this->call(PacotesSeeder::class);
    }
}
